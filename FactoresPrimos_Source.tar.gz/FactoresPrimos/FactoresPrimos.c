/*Programa que descompone en factores primos*/

#include </opt/FactoresPrimos/hola.h>
#include </opt/FactoresPrimos/byebye.h>
#include </opt/FactoresPrimos/descomposicion.h>
#include <stdio.h>
#include <stdlib.h>

int main(){

	int n;

	hola();

	printf("\x1B[0m\nEste programa descompone un numero dado en factores primos.\n");

	n=0;

	descomposicion(n);

	adios();

	return 0;

}
