sudo rm /usr/bin/FactoresPrimos
rm ~/.local/share/applications/FactoresPrimos.desktop
rm -R ~/.FactoresPrimos/
rm ~/Escritorio/FactoresPrimos.desktop
sudo rm /usr/share/applications/FactoresPrimos.desktop
sudo rm /usr/bin/UNINSTALL_FactoresPrimos.sh
rm ~/Escritorio/FactoresPrimos_Uninstall.desktop
sudo rm /usr/share/applications/FactoresPrimos_Uninstall.desktop
sudo rm /usr/share/pixmaps/FactoresPrimos.png
